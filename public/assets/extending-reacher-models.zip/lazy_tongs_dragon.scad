// ============================================================================
// Lazy-Tongs Snapping Dragon  —  extending scissor grabber-reacher
// ----------------------------------------------------------------------------
// A Nuremberg-scissor (lazy-tongs) lattice: squeeze the tail handle and the
// dragon's NECK telescopes forward while the HEAD snaps shut — one degree of
// freedom, coupled by the scissor's shared link-angle alpha.
//
//   * every link shares angle alpha to the long (reach) axis
//   * shrink alpha  ->  cells go long+thin  ->  lattice EXTENDS
//   * jaws are the last links' tails, opening = 2*alpha -> they CLOSE as it
//     extends.  So a single squeeze reaches out AND bites.
//
// Snap-pin ASSEMBLED build: flat links + push-in snap rivets (one pivot SKU).
// MakerWorld "Exoskeleton & Articulated Mechanism" contest entry.
//
// part= link | crest | handle | jaw_upper | jaw_lower | pin
//       all  (assembled, extended)  |  collapsed (assembled, jaws open)
//       exploded
// ============================================================================

part = "all";

// ---- scissor geometry ------------------------------------------------------
link_L    = 46;    // pivot-to-pivot span of one scissor link (mm)
n_units   = 5;     // number of scissor cells (reach scales with this)
alpha_open = 54;   // [deg] relaxed: short lattice, jaws OPEN
alpha_ext  = 22;   // [deg] squeezed: long lattice, jaws nearly CLOSED

// ---- bar / pivot -----------------------------------------------------------
bar_w      = 9.0;  // link width
bar_t      = 3.2;  // link thickness (one rail layer)
hole_d     = 4.2;  // pivot hole (spins on the pin shaft)
layer_gap  = 0.45; // z gap between the two rails so links don't rub

// ---- pin (snap rivet) ------------------------------------------------------
pin_shaft_d = 3.7;                    // < hole_d -> free pivot
pin_flange_d = 8.0;
pin_flange_t = 1.4;
pin_barb_d   = 4.9;                   // > hole_d -> retains. 0.7mm over -> 0.35/side catch.
                                      // NB: barb must squeeze to hole_d to pass; the collet's
                                      // max closure ~= slot_w, so keep (barb_d-hole_d) < slot_w
                                      // or the fingers bottom out, jam, and SNAP when forced.
pin_clear    = 0.3;                   // barb clearance above top link (tight -> ledge seats, no wiggle-out)

// ---- ends ------------------------------------------------------------------
handle_len = 44;   // tail-handle reach behind the base
jaw_len    = 34;   // head/jaw reach ahead of the last node

$fn = 44;
eps = 0.01;

// ---- derived scissor node math --------------------------------------------
function ddx(a) = link_L*cos(a);         // node pitch along reach axis
function hh(a)  = link_L*sin(a);         // rail separation (lattice width)
function topN(i,a) = [i*ddx(a), +hh(a)/2];
function botN(i,a) = [i*ddx(a), -hh(a)/2];

zA = 0;                    // lower rail (belly)
zB = bar_t + layer_gap;    // upper rail (spine)
stack_h = 2*bar_t + layer_gap;

// ============================================================================
//  LINK BODIES (flat, centered on origin, long axis = X, holes -L/2,0,+L/2)
// ============================================================================
module link_body_2d(holed=true) {
    difference() {
        hull() {
            translate([-link_L/2,0]) circle(d=bar_w);
            translate([ link_L/2,0]) circle(d=bar_w);
        }
        // belly (A) links are SOLID in the PIP build — the pivot post fuses to
        // them, so they carry no bore.  Spine (B) links keep clearance bores.
        if (holed) for (x=[-link_L/2, 0, link_L/2]) translate([x,0]) circle(d=hole_d);
    }
}

// bold continuous dragon-back ridge — the spine rail is the TOP rail (nothing
// above it) so a full crest is collision-safe; just keep clear of the 3 holes.
// Spine ridge spikes. MUST clear every pivot cap: bores sit at x=0,+/-link_L/2,
// caps are Ø pip_cap_d. A spike centre must stand >= cap_r + spike_r + clearance
// from any bore, else the cap fuses this spine link to its belly partner's post
// (was: spikes at x=+/-5 collided with the centre cap -> fused rails). So the
// ridge lives ONLY in the safe bands between pivots.
module crest_spikes() {
    for (s=[-1,1])
        for (j=[0:1]) {
            x  = s*(8.5 + j*6.0);                // 8.5, 14.5 : between centre & end bores
            h  = 4.4 - j*0.6;                    // graded height -> ridge look
            translate([x,0,bar_t]) rotate([0,0,45])
                cylinder(h=h, r1=2.7, r2=0, $fn=4);
        }
}

module link(holed=true)  linear_extrude(bar_t) link_body_2d(holed);   // plain (belly rail)
module crest() { link(true); crest_spikes(); }                // spined (spine rail)

// ---- handle / tail link (tail hangs off the -X (proximal) end) -------------
module handle(top=false, holed=true) {
    tail_w0 = bar_w; tail_w1 = 6.5;
    union() {
        link(holed);
        // tapering tail
        linear_extrude(bar_t)
            hull() {
                translate([-link_L/2,0]) circle(d=tail_w0);
                translate([-link_L/2-handle_len+7,0]) circle(d=tail_w1);
            }
        // tail tip flare (grip paddle / dragon tail fin)
        linear_extrude(bar_t)
            translate([-link_L/2-handle_len,0])
                hull() {
                    circle(d=13);
                    translate([6,0]) circle(d=tail_w1);
                }
        if (top) translate([-link_L/2-handle_len*0.45,0,0]) crest_spikes_tail();
    }
}
module crest_spikes_tail() {
    for (x=[0, -12])
        translate([x,0,bar_t]) rotate([0,0,45])
            cylinder(h=2.6, r1=2.0, r2=0, $fn=4);
}

// ============================================================================
//  DRAGON HEAD  —  jaw tails off the +X (distal) end of the last-cell links
//  jaw_upper rides lower rail A (reaches TOP node); jaw_lower rides upper
//  rail B (reaches BOTTOM node). Teeth are grown DOWN/UP in z to close the
//  layer_gap so they actually clamp.
// ============================================================================
tooth_grow = bar_t + layer_gap + 0.4;   // z overlap so jaws meet
jaw_bias   = 34;   // [deg] tails bent inward so jaws CLOSE at ~alpha_ext (not alpha=0)

module jaw_profile_2d(upper=true) {
    // widened jaw plate off the +X end
    hull() {
        translate([link_L/2,0]) circle(d=bar_w);
        translate([link_L/2+jaw_len*0.55, upper?  2.5 : -2.5]) circle(d=bar_w+2);
        translate([link_L/2+jaw_len,       upper?  0.5 : -0.5]) circle(d=3.2);
    }
}
module teeth_2d(upper=true) {
    // row of triangular teeth along the inner edge of the jaw
    n_t = 5; x0 = link_L/2+7; x1 = link_L/2+jaw_len-3;
    for (k=[0:n_t-1]) {
        xt = x0 + (x1-x0)*k/(n_t-1);
        yt = upper ? -0.5 : 0.5;   // inner edge
        translate([xt, yt])
            polygon(upper
                ? [[-2.1,0],[2.1,0],[0,-3.2]]
                : [[-2.1,0],[2.1,0],[0, 3.2]]);
    }
}
// rotate a head group about the distal node so the jaw tail bends inward
module about_distal(bias) {
    translate([link_L/2,0,0]) rotate([0,0,bias]) translate([-link_L/2,0,0]) children();
}
head_h = zB + bar_t;   // full head Z-height (both rails) so jaws overlap & clamp

module jaw_upper(holed=false) {
    linear_extrude(bar_t) link_body_2d(holed);       // belly member -> SOLID (post fuses)
    about_distal(-jaw_bias) {
        linear_extrude(bar_t) jaw_profile_2d(true);
        // teeth span the FULL head height (z0..head_h) so they reach into the
        // lower jaw's rail band and actually clamp (grows UP -> prints flat).
        linear_extrude(head_h) teeth_2d(true);
        // --- neck frill: fan of spikes rising behind the head ("something on top")
        for (f=[-1:1])
            translate([link_L/2+2, 2.2, bar_t])
                rotate([0,0, f*22]) rotate([-18,0,0])
                    cylinder(h=9 - abs(f)*1.8, r1=2.6, r2=0, $fn=4);
        // --- paired brow horns sweeping back
        for (hx=[link_L/2+10, link_L/2+13.5])
            translate([hx, 3.4, bar_t]) rotate([14,0,32])
                cylinder(h=8.5, r1=2.7, r2=0, $fn=4);
        // --- eye bump + nostril
        translate([link_L/2+6, 3.7, bar_t]) sphere(d=4.8);          // eye ridge
        translate([link_L/2+jaw_len-4, 1.6, bar_t]) sphere(d=3.0);  // nostril
    }
}
module jaw_lower() {
    linear_extrude(bar_t) link_body_2d();
    about_distal(jaw_bias) {
        linear_extrude(bar_t) jaw_profile_2d(false);
        // lower teeth occupy its own rail band (part z0..bar_t -> assembled
        // zB..zB+bar_t), overlapping the upper jaw's full-height teeth there.
        linear_extrude(bar_t) teeth_2d(false);
    }
}

// ============================================================================
//  SNAP-RIVET PIN
// ============================================================================
module pin() {
    barb_land = 0.9;                     // STRAIGHT catch shelf: a real ledge (not a cone knife-edge)
    barb_h  = 2.6;                        // cone lead-in above the land -> gentle push-in
    slot_w  = 1.4;                       // relief slot width > (barb_d-hole_d)=0.7 -> closure headroom
    barb_z0 = pin_flange_t + stack_h + pin_clear;           // barb base = catch shelf
    tip_z   = barb_z0 + barb_land + barb_h;                 // barb apex
    slot_z0 = pin_flange_t + 0.6;        // long fingers (~1/L^3 softer) -> low strain, no crack
    difference() {
        union() {
            cylinder(d=pin_flange_d, h=pin_flange_t);                          // flange
            translate([0,0,pin_flange_t-eps])
                cylinder(d=pin_shaft_d, h=stack_h+pin_clear);                  // shaft
            translate([0,0,barb_z0-eps])
                cylinder(d=pin_barb_d, h=barb_land);                          // straight catch land (flat 90 undercut)
            translate([0,0,barb_z0+barb_land-eps])
                cylinder(d1=pin_barb_d, d2=1.4, h=barb_h);                     // cone lead-in (d2 tip)
        }
        // CROSS relief slots running from the barb apex DOWN through the shaft:
        // long 4-finger collet (stiffness ~1/L^3) so the barb actually squeezes
        // to hole_d and springs back. Stops above the flange so the head holds.
        for (r=[0,90]) rotate([0,0,r]) {
            translate([-slot_w/2, -pin_barb_d, slot_z0])
                cube([slot_w, 2*pin_barb_d, tip_z - slot_z0 + eps]);
            // rounded slot root: kills the sharp cube corner (crack initiator)
            translate([0, -pin_barb_d, slot_z0]) rotate([-90,0,0])
                cylinder(d=slot_w, h=2*pin_barb_d);
        }
    }
}
module pin_preview() {  // slim visual stand-in for the assembly render
    color("dimgray") translate([0,0,-pin_flange_t])
        cylinder(d=pin_shaft_d+0.6, h=stack_h+pin_flange_t+2);
}

// ============================================================================
//  ASSEMBLY
// ============================================================================
module place(i, isA, a) {
    p0 = isA ? botN(i,a)   : topN(i,a);
    p1 = isA ? topN(i+1,a) : botN(i+1,a);
    c  = (p0+p1)/2;
    ang = isA ? a : -a;
    z  = isA ? zA : zB;
    translate([c[0], c[1], z]) rotate([0,0,ang]) children();
}

module assembly(a, pins=true) {
    // ---- lower rail A (belly): plain links, handle at 0, upper-jaw at end ---
    for (i=[0:n_units-1]) place(i, true, a) {
        if (i==0)             handle(false); // grip points OUT off the proximal free end
        else if (i==n_units-1) jaw_upper();
        else                  link();
    }
    // ---- upper rail B (spine): crest links, handle at 0, lower-jaw at end ---
    for (i=[0:n_units-1]) place(i, false, a) {
        if (i==0)              handle(true);
        else if (i==n_units-1) jaw_lower();
        else                   crest();
    }
    // ---- pins ----
    if (pins) {
        for (i=[0:n_units-1]) translate([(i+0.5)*ddx(a),0,0]) pin_preview();  // crossings
        for (i=[1:n_units-1]) {                                              // side nodes
            translate([i*ddx(a),+hh(a)/2,0]) pin_preview();
            translate([i*ddx(a),-hh(a)/2,0]) pin_preview();
        }
    }
}

// ============================================================================
//  PRINT-IN-PLACE BUILD  —  one print, comes off the bed already articulating
// ----------------------------------------------------------------------------
// No separate pins. Belly (A) links print SOLID on the bed; each pivot is a
// capped POST fused to the belly link that rises through the floating spine (B)
// link's clearance bore and caps over it (captured, free to spin). Uniform:
// every one of the 3n-2 pivots = A(lower,fused-post) + B(upper,rides).
// ============================================================================
pip_zgap    = 0.4;                 // A-top -> B-bottom air gap (prints as short bridge)
pip_shaft_d = hole_d - 0.7;        // 3.5: rides B's 4.2 bore w/ 0.35/side running clearance
pip_capgap  = 0.4;                 // B-top -> cap-underside gap (bridge; lets B rotate)
pip_cap_d   = hole_d + 2.4;        // 6.6: overhangs the bore -> B captured, can't lift off
pip_cap_t   = 1.2;

zB_pip   = bar_t + pip_zgap;                        // spine-rail floor in the PIP stack
cap_z0   = zB_pip + bar_t + pip_capgap;             // cap underside
pip_top  = cap_z0 + pip_cap_t;

module pip_post() {
    // shaft z0..cap (fuses through the solid belly link, rides B's bore), + cap
    cylinder(d=pip_shaft_d, h=cap_z0 + eps);
    translate([0,0,cap_z0]) cylinder(d=pip_cap_d, h=pip_cap_t);
}

// all 3n-2 pivot posts in world XY: n crossings + 2(n-1) interior side nodes
module pip_posts(a) {
    for (i=[0:n_units-1]) translate([(i+0.5)*ddx(a), 0, 0])       pip_post();  // crossings
    for (i=[1:n_units-1]) {                                                    // side nodes
        translate([i*ddx(a), +hh(a)/2, 0]) pip_post();
        translate([i*ddx(a), -hh(a)/2, 0]) pip_post();
    }
}

module assembly_pip(a) {
    // belly rail A (z0, on bed): SOLID links, handle at 0, upper-jaw at end
    for (i=[0:n_units-1]) place_pip(i, true, a) {
        if      (i==0)          handle(false, false);   // solid tail handle
        else if (i==n_units-1)  jaw_upper(false);       // solid jaw base
        else                    link(false);            // solid middle link
    }
    // spine rail B (floating zB_pip): CREST links w/ clearance bores
    for (i=[0:n_units-1]) place_pip(i, false, a) {
        if      (i==0)          handle(true, true);
        else if (i==n_units-1)  jaw_lower();
        else                    crest();
    }
    pip_posts(a);
}

// PIP placement: same node math as place() but belly on bed, spine at zB_pip
module place_pip(i, isA, a) {
    p0 = isA ? botN(i,a)   : topN(i,a);
    p1 = isA ? topN(i+1,a) : botN(i+1,a);
    c  = (p0+p1)/2;
    ang = isA ? a : -a;
    z  = isA ? 0 : zB_pip;
    translate([c[0], c[1], z]) rotate([0,0,ang]) children();
}

// PIP print plate: the working lattice (collapsed pose = compact), one print
module pip_plate() {
    assembly_pip(alpha_open);
}

// ============================================================================
//  PART SELECTION
// ============================================================================
// ============================================================================
//  EXPLODED  —  lift the spine rail, float pins above each joint
// ============================================================================
module exploded() {
    a = 38; EX = 26;
    // belly rail A (z0): plain links / handle / upper-jaw
    for (i=[0:n_units-1]) place(i, true, a) {
        if (i==0)              handle(false);
        else if (i==n_units-1) jaw_upper();
        else                   link();
    }
    // spine rail B lifted by EX
    translate([0,0,EX]) for (i=[0:n_units-1]) place(i, false, a) {
        if (i==0)              handle(true);
        else if (i==n_units-1) jaw_lower();
        else                   crest();
    }
    // pins floating above their joints
    for (i=[0:n_units-1]) translate([(i+0.5)*ddx(a),0,zB+EX+18]) pin_preview();
    for (i=[1:n_units-1]) {
        translate([i*ddx(a),+hh(a)/2,zB+EX+18]) pin_preview();
        translate([i*ddx(a),-hh(a)/2,zB+EX+18]) pin_preview();
    }
}

// ============================================================================
//  PRINT PLATE  —  every part laid flat, correct quantities (256 mm bed)
// ============================================================================
module plate() {
    row = link_L + bar_w + 4;
    // 3 plain links + 3 crest links, two columns
    for (k=[0:2]) {
        translate([0,  k*(bar_w+4), 0]) link();
        translate([0, -(k+1)*(bar_w+4), 0]) crest();
    }
    // handles
    translate([row*1.9, 0, 0]) handle(false);
    translate([row*1.9, bar_w+16, 0]) handle(true);
    // jaws
    translate([row*1.9, -(bar_w+20), 0]) jaw_upper();
    translate([row*1.9, -(2*bar_w+34), 0]) jaw_lower();
    // 13 pins standing in a grid
    for (i=[0:12]) translate([ -42 - (i%7)*11, -6 + floor(i/7)*11, 0]) pin();
}

// ============================================================================
//  PER-STEP CUMULATIVE BUILD  (guide flipbook; highlight the just-added stage)
// ============================================================================
step = 99;
hl   = "#ffd23f";
module pin_at() translate([0,0,-pin_flange_t]) pin();
module step_build() {
    a = 34;
    // 1: belly rail
    color(step==1?hl:"#c2c2c2")
        for (i=[0:n_units-1]) place(i,true,a) {
            if      (i==0)          handle(false);
            else if (i==n_units-1)  jaw_upper();
            else                    link();
        }
    // 2: spine rail
    if (step>=2) color(step==2?hl:"#8aa0c8")
        for (i=[0:n_units-1]) place(i,false,a) {
            if      (i==0)          handle(true);
            else if (i==n_units-1)  jaw_lower();
            else                    crest();
        }
    // 3: crossing pins
    if (step>=3) color(step==3?hl:"#5a5a5a")
        for (i=[0:n_units-1]) translate([(i+0.5)*ddx(a),0,0]) pin_at();
    // 4: side-joint pins
    if (step>=4) color(step==4?hl:"#5a5a5a")
        for (i=[1:n_units-1]) {
            translate([i*ddx(a),+hh(a)/2,0]) pin_at();
            translate([i*ddx(a),-hh(a)/2,0]) pin_at();
        }
}

if      (part=="link")        link();
else if (part=="crest")       crest();
else if (part=="handle")      handle(true);
else if (part=="handle_plain")handle(false);
else if (part=="jaw_upper")   jaw_upper();
else if (part=="jaw_lower")   jaw_lower();
else if (part=="pin")         pin();
else if (part=="all")         assembly(alpha_ext);     // extended + biting
else if (part=="collapsed")   assembly(alpha_open);    // short + jaws open
else if (part=="pip")         assembly_pip(alpha_open);// PRINT-IN-PLACE working lattice
else if (part=="pip_plate")   pip_plate();             // PIP lattice + loose spring (1 print)
else if (part=="exploded")    exploded();
else if (part=="plate")       plate();
else if (part=="step")        step_build();
