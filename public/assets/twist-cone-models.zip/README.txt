Twist Cone

Two original STL parts provided to 3DP for Good.
Core = Part Studio 1 - Part 1.stl
Shell = Part Studio 1 - Part 2.stl

Original STL bytes and shared coordinates are preserved. Print both parts.
The website uses reduced mesh previews for smoother interaction.
The movement preview illustrates the helical motion; it is not a print-clearance or durability test.
